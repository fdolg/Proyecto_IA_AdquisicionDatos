﻿using System;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;

namespace Interfaz_usuario
{
    public partial class Form1 : Form
    {
        private string CadenaRecibida;
        public Form1()
        {
            InitializeComponent();
        }

        private void BuscarPuertos()
        {
            //Obtener el nombre de puertos existentes en el equipo
            string[] NombresPuertos = SerialPort.GetPortNames();
            //Eliminar los elementos del control ComboBox
            cmbPuertos.Items.Clear();
            //Ciclo para agregar los nombres de los puertos al control ComboBox
            foreach (string Nombre in NombresPuertos)
                cmbPuertos.Items.Add(Nombre);
            //Agregar el mensaje en la propiedad del control
            cmbPuertos.Text = "Seleccione Puerto";
        }
        //Método que se genera al hacer clic en el botón Actualizar
        private void btnActualizarPuertos_Click_1(object sender, EventArgs e)
        {
            BuscarPuertos();
        }
        //Método que se genera cuando se cambia el índice del ComboBox cmbPuertos
        private void cmbPuertos_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //Asignar el nombre actual del ComboBox a la propiedad PortName del puerto
            serialPort1.PortName = cmbPuertos.SelectedItem.ToString();
        }
        //Método que se genera cuando se hace clic en el botón para Conectar
        private void btnConectar_Click(object sender, EventArgs e)
        {
            try
            {
                //Abrir el puerto
                serialPort1.Open();
                MessageBox.Show("Puerto Abierto");
            }
            catch (Exception error)
            {
                //Si ocurre una excepción, enviar el mensaje al usuario 
                MessageBox.Show(error.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        //Evento que se genera cuando se hace clic en el botón desconectar
        private void btnDesconectar_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
                MessageBox.Show("Puerto Cerrado");
            }
            else
                MessageBox.Show("El puerto está cerrado");
        }

        //Evento que se genera cuando se reciben datos por el puerto
        private void serialPort1_DataReceived_1(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                Thread.Sleep(1000);
                //Asignar los datos existentes en el búfer al atributo CadenaRecibida
                CadenaRecibida = serialPort1.ReadLine();
                BeginInvoke(new LineReceivedEvent(LineReceived), CadenaRecibida);
            }catch(Exception error)
            {
                MessageBox.Show(error.Message, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Metodo para poder leer los datos en el puerto
        private delegate void LineReceivedEvent(string CadenaRecibida);

        private void LineReceived(string line)
        {
            label4.Text = line;
        }

        private void btnComenzar_Click(object sender, EventArgs e)
        {
            tmrActualizarDatos.Start();
            label4.Visible = true;
            btnDetener.Enabled = true;
            btnComenzar.Enabled = false;
        }

        //En este método se añaden los datos al archivo .csv linea a linea
        private void Construir_BaseDatos()
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.WriteLine("M" + txbEtiqueta.Text + "\r");//Envia la cadena que permite trabaje el sensor y la etiqueta
                Thread.Sleep(1000);
            }
            else
            {
                MessageBox.Show("Necesita conectar al puerto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tmrActualizarDatos.Stop();
            }
            using (StreamWriter sw = new StreamWriter("C:/Users/agroo/Downloads/Proyecto_IA_AdquisicionDatos-master/Proyecto_IA_AdquisicionDatos/"+ txtFileName.Text + ".csv", true))// Falta añadir la ruta completa para crear el doc
            {
                sw.Write(CadenaRecibida);
            }
        }

        private void tmrActualizarDatos_Tick(object sender, EventArgs e)
        {
            Construir_BaseDatos();
        }

        //Con este evento se detiene el registro de datos
        private void btnDetener_Click(object sender, EventArgs e)
        {
            tmrActualizarDatos.Stop();
            label4.Visible = false;
            btnComenzar.Enabled = true;
            btnDetener.Enabled = false;
        }

    }
}
